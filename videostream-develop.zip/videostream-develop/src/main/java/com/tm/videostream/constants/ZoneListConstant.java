package com.tm.videostream.constants;

public class ZoneListConstant {

	public ZoneListConstant() {
		super();
	}

	public static final String SINGLE_SCHEDULE_ZONE="Single";
	public static final String MULTI_SCHEDULE_ZONE="Multi";
}

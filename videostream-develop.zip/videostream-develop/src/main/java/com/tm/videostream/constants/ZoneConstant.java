package com.tm.videostream.constants;

public class ZoneConstant {

	private ZoneConstant() {
		super();
	}
	
	public static final String GLOBAL_ZONE="Global_Zone";

}

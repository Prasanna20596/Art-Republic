package com.tm.videostream.constants;

public class RoleConstant {

	private RoleConstant() {
		super();
	}
	
	public static final String ADMIN_ROLE="ROLE_Admin";
	
}

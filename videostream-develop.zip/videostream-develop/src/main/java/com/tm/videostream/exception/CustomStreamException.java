package com.tm.videostream.exception;

public class CustomStreamException extends RuntimeException {

	public CustomStreamException(String message) {
		super(message);
	}

}

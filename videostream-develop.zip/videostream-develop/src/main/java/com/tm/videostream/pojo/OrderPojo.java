package com.tm.videostream.pojo;

public class OrderPojo {

	private String orderColumnOne;
	private String sortByColumnOne;
	private String orderColumnTwo;
	private String sortByColumnTwo;
	private String orderColumnThree;
	private String sortByColumnThree;
	private String orderColumnFour;
	private String sortByColumnFour;
	private String orderColumnFive;
	private String sortByColumnFive;

	public String getOrderColumnOne() {
		return orderColumnOne;
	}

	public void setOrderColumnOne(String orderColumnOne) {
		this.orderColumnOne = orderColumnOne;
	}

	public String getSortByColumnOne() {
		return sortByColumnOne;
	}

	public void setSortByColumnOne(String sortByColumnOne) {
		this.sortByColumnOne = sortByColumnOne;
	}

	public String getOrderColumnTwo() {
		return orderColumnTwo;
	}

	public void setOrderColumnTwo(String orderColumnTwo) {
		this.orderColumnTwo = orderColumnTwo;
	}

	public String getSortByColumnTwo() {
		return sortByColumnTwo;
	}

	public void setSortByColumnTwo(String sortByColumnTwo) {
		this.sortByColumnTwo = sortByColumnTwo;
	}

	public String getOrderColumnThree() {
		return orderColumnThree;
	}

	public void setOrderColumnThree(String orderColumnThree) {
		this.orderColumnThree = orderColumnThree;
	}

	public String getSortByColumnThree() {
		return sortByColumnThree;
	}

	public void setSortByColumnThree(String sortByColumnThree) {
		this.sortByColumnThree = sortByColumnThree;
	}

	public String getOrderColumnFour() {
		return orderColumnFour;
	}

	public void setOrderColumnFour(String orderColumnFour) {
		this.orderColumnFour = orderColumnFour;
	}

	public String getSortByColumnFour() {
		return sortByColumnFour;
	}

	public void setSortByColumnFour(String sortByColumnFour) {
		this.sortByColumnFour = sortByColumnFour;
	}

	public String getOrderColumnFive() {
		return orderColumnFive;
	}

	public void setOrderColumnFive(String orderColumnFive) {
		this.orderColumnFive = orderColumnFive;
	}

	public String getSortByColumnFive() {
		return sortByColumnFive;
	}

	public void setSortByColumnFive(String sortByColumnFive) {
		this.sortByColumnFive = sortByColumnFive;
	}

}

package com.tm.videostream.pojo;

public class Range {

	private String formattedStartDateTime;
	private String formattedEndDateTime;

	public Range(String formattedStartDateTime, String formattedEndDateTime) {
		super();
		this.formattedStartDateTime = formattedStartDateTime;
		this.formattedEndDateTime = formattedEndDateTime;
	}

	public String getFormattedStartDateTime() {
		return formattedStartDateTime;
	}

	public void setFormattedStartDateTime(String formattedStartDateTime) {
		this.formattedStartDateTime = formattedStartDateTime;
	}

	public String getFormattedEndDateTime() {
		return formattedEndDateTime;
	}

	public void setFormattedEndDateTime(String formattedEndDateTime) {
		this.formattedEndDateTime = formattedEndDateTime;
	}

}

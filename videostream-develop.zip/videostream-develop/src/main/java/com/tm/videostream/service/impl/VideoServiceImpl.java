package com.tm.videostream.service.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.zone.ZoneRulesException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.apache.catalina.connector.ClientAbortException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tm.videostream.constants.RoleConstant;
import com.tm.videostream.dto.ScheduleVideoDTO;
import com.tm.videostream.dto.VideoDTO;
import com.tm.videostream.entity.ScheduleVideo;
import com.tm.videostream.entity.User;
import com.tm.videostream.entity.UserScheduleVideo;
import com.tm.videostream.entity.Video;
import com.tm.videostream.exception.CustomStreamException;
import com.tm.videostream.pojo.Range;
import com.tm.videostream.pojo.request.FilterVideoRequest;
import com.tm.videostream.pojo.request.ScheduleVideoRequestPojo;
import com.tm.videostream.pojo.request.StatusUpdateRequestPOJO;
import com.tm.videostream.pojo.request.VideoDetailsRequestPOJO;
import com.tm.videostream.pojo.request.ZoneDateTimeRequest;
import com.tm.videostream.repository.ScheduleVideoRepository;
import com.tm.videostream.repository.UserRepository;
import com.tm.videostream.repository.UserScheduleVideoRepository;
import com.tm.videostream.repository.VideoRepository;

import com.tm.videostream.service.VideoService;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**
 * This class provides the implementation of the VideoService interface. It
 * contains methods to handles save video details, list the videos by filter
 * option and streaming the video.
 */
@Service
public class VideoServiceImpl implements VideoService {

	Logger logger = LoggerFactory.getLogger(VideoServiceImpl.class);

	@Autowired
	private VideoRepository videoRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ScheduleVideoRepository scheduleVideoRepository;

	@Autowired
	private UserScheduleVideoRepository userScheduleVideoRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * This method is used to save the video details in database
	 * 
	 * @param file
	 * @param title
	 * @param description
	 * @param username
	 * @param size
	 * @param duration
	 * @param videoThumbnail
	 * @return boolean
	 */
	public boolean saveVideoDetails(MultipartFile file, String title, String description, String username, float size,
			float duration, MultipartFile videoThumbnail) {
		logger.info("Received the request to save the video details");
		try {
			logger.info("Gathering the video details from request");

			String projectDirectory = System.getProperty("user.dir");
			String videoDirectory = projectDirectory + "/Videos/";

			Path directory = Paths.get(videoDirectory);
			if (!Files.exists(directory)) {
				Files.createDirectories(directory);
			}

			String videoExtension = StringUtils.getFilenameExtension(file.getOriginalFilename());

			String uuid = UUID.randomUUID().toString();
			String filePath = Paths.get(videoDirectory, uuid + "." + videoExtension).toString();

			Files.copy(file.getInputStream(), Paths.get(filePath));

			String thumbnailDirectory = projectDirectory + "/Thumbnail/";

			Path thumbnail = Paths.get(thumbnailDirectory);
			if (!Files.exists(thumbnail)) {
				Files.createDirectories(thumbnail);
			}
			String thumbnailExtension = StringUtils.getFilenameExtension(videoThumbnail.getOriginalFilename());

			String thumbnailUuid = UUID.randomUUID().toString();
			String thumbnailFilePath = Paths.get(thumbnailDirectory, thumbnailUuid + "." + thumbnailExtension)
					.toString();

			Files.copy(file.getInputStream(), Paths.get(thumbnailFilePath));

			User user = userRepository.findByUsername(username.trim());

			Video saveVideo = new Video();

			saveVideo.setTitle(title);
			saveVideo.setDescription(description);
			saveVideo.setFilename(uuid + "." + videoExtension);
			saveVideo.setVideoThumbnail(thumbnailUuid + "." + thumbnailExtension);
			saveVideo.setApprovalStatus("NEW");
			saveVideo.setCreatedBy(user.getName());
			saveVideo.setUpdatedBy(user.getName());
			saveVideo.setSize(size);
			saveVideo.setDuration(duration);
			saveVideo.setUser(user);

			videoRepository.save(saveVideo);
			logger.info("Video details are saved in database");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to save the video details in database");
			return false;
		}

	}

	/**
	 * This method is used to get the content type(Ex:mp4.avi etc) from file
	 * 
	 * @param filename
	 * @return String
	 */
	private String getContentType(String filename) {
		logger.info("Get the content type for file");
		try {
			String isContentType = Files.probeContentType(Paths.get(filename));
			logger.info("Content type is identified");
			return isContentType;
		} catch (IOException e) {
			logger.error("Cannot get the content type for file");
			return "Cannot get content type for file";
		}
	}

	/**
	 * This method is used to streaming the video
	 * 
	 * @param filename
	 * @return ResponseEntity<StreamingResponseBody>
	 */
	public ResponseEntity<StreamingResponseBody> streamingVideoByFileName(String filename) {
		logger.info("Received the request to streaming the video");
		try {
			logger.info("Get the file from directory");

			String videoDirectory = System.getProperty("user.dir") + "/Videos/";

			logger.info("Valid token, Next go to video streaming process");

			File file = new File(videoDirectory, filename);

			StreamingResponseBody responseBody = outputStream -> {
				logger.info("Get the input stream content from video");
				try (InputStream inputStream = new FileInputStream(file)) {
					byte[] buffer = new byte[1024];
					int length;
					while ((length = inputStream.read(buffer)) != -1) {
						outputStream.write(buffer, 0, length);
					}
				} catch (ClientAbortException e) {
					logger.warn("Client disconnected during streaming");
				} catch (IOException e) {
					logger.error("Unable to write content");
					e.printStackTrace();
				}
			};

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType(getContentType(filename)));
			headers.set("Accept-Ranges", "bytes");

			logger.info("Video is streamed");
			return ResponseEntity.ok().headers(headers).body(responseBody);
		} catch (Exception e) {
			logger.error("Unable to streaming the video");
			throw new CustomStreamException("Unable to streaming the video");
		}
	}

	/**
	 * This method is used to update the approval status by fileId
	 * 
	 * @param statusUpdateRequestPOJO
	 * @return boolean
	 */
	public boolean updateApprovalStatusByFileId(StatusUpdateRequestPOJO statusUpdateRequestPOJO) {
		logger.info("Received the request to update the video status");
		try {
			logger.info("Get the details based on fileId");
			User user = userRepository.findByUsername(statusUpdateRequestPOJO.getUsername().trim());
			if (user.getRoles().getRoleName().equals(RoleConstant.ADMIN_ROLE)) {
				int rowsAffected = videoRepository.updateApprovalStatusByFileId(statusUpdateRequestPOJO.getFileId(),
						statusUpdateRequestPOJO.getApprovalStatus().trim(), user.getName());
				if (rowsAffected > 0) {
					logger.info("Video status is updated");
					return true;
				} else {
					logger.warn("No video found with fileId: {}", statusUpdateRequestPOJO.getFileId());
					return false;
				}
			} else {
				logger.error("Given user does not update the approval status");
				return false;
			}
		} catch (Exception e) {
			logger.error("Unable to update the video status", e);
			return false;
		}
	}

	/**
	 * This method is used to fetch the video's based on user role with approval
	 * status
	 * 
	 * @param videoDetailsRequestPOJO
	 * @return List<VideoDTO>
	 */
	public List<VideoDTO> fetchVideoDetails(VideoDetailsRequestPOJO videoDetailsRequestPOJO) {
		logger.info("Received the request to fetch the video's based the user role");
		try {
			logger.info("Pass the username to find the details");
			User user = userRepository.findByUsername(videoDetailsRequestPOJO.getUsername().trim());
			List<VideoDTO> videoDTOs;

			Pageable pageable = PageRequest.of(videoDetailsRequestPOJO.getPageNo() - 1,
					videoDetailsRequestPOJO.getLimitSize());

			if (user.getRoles().getRoleName().equals(RoleConstant.ADMIN_ROLE)) {
				videoDTOs = videoRepository
						.findAdminVideoByApprovalStatus(videoDetailsRequestPOJO.getApprovalStatus().trim(), pageable);
				logger.info("Fetch the video's based on admin");
			} else {
				videoDTOs = videoRepository.findCustomerVideoByApprovalStatus(
						videoDetailsRequestPOJO.getApprovalStatus().trim(),
						videoDetailsRequestPOJO.getUsername().trim(), pageable);
				logger.info("Fetch the video's based on customer");
			}
			logger.info("Video's are fetched");
			return videoDTOs;
		} catch (Exception e) {
			logger.error("Unable to fecth the video details ");
			throw new CustomStreamException("Unable to fecth the video details");
		}
	}

	/**
	 * This method is used to fetch the video's without current admin or customer
	 * video
	 * 
	 * @param approvalStatus
	 * @param username
	 * @return List<VideoDTO>
	 */
	public List<VideoDTO> fetchVideoWithoutCurrentUserVideo(VideoDetailsRequestPOJO videoDetailsRequestPOJO) {
		logger.info("Received the request to fetch the video's without current admin or customer");
		List<VideoDTO> videoDTOs;
		try {
			videoDTOs = videoRepository.findVideosWithoutCurrentAdminOrCustomer(
					videoDetailsRequestPOJO.getApprovalStatus().trim(), videoDetailsRequestPOJO.getUsername().trim());
			logger.info("Video's are fetched without current user");
		} catch (Exception e) {
			logger.error("Unable to fecth the video details without current user");
			throw new CustomStreamException("Unable to fecth the video details without current user");
		}
		return videoDTOs;
	}

	/**
	 * This method is used to fetch the video's by filter option
	 * 
	 * @param filterVideoRequest
	 * @return List<VideoDTO>
	 */
	public List<VideoDTO> fetchFilterVideoDetails(FilterVideoRequest filterVideoRequest) {
		logger.info("Received the request to fetch the videos by filter");
		try {

			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("FILTER_OPTION_VIDEO");

			query.registerStoredProcedureParameter("userId", Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("roleName", String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("approvalStatus", String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("limitSize", Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("pageNo", Integer.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("filterPojo", String.class, ParameterMode.IN);

			String filterPojoJson = objectMapper.writeValueAsString(filterVideoRequest.getFilterPojo());

			User user = userRepository.findByUniqueId(filterVideoRequest.getUniqueId());

			String roleName = user.getRoles().getRoleName();
			if (roleName.startsWith("ROLE_")) {
				roleName = roleName.substring("ROLE_".length());
			}

			query.setParameter("userId", user.getUserId());
			query.setParameter("roleName", roleName);
			query.setParameter("approvalStatus", filterVideoRequest.getApprovalStatus());
			query.setParameter("limitSize", filterVideoRequest.getLimitSize());
			query.setParameter("pageNo", filterVideoRequest.getLimitSize() * (filterVideoRequest.getPageNo() - 1));
			query.setParameter("filterPojo", filterPojoJson);

			List<Object[]> resultList = query.getResultList();

			List<VideoDTO> videoDTOs = new ArrayList<>();
			for (Object[] result : resultList) {
				int fileId = (int) result[0];
				String title = String.valueOf(result[1]);
				String description = String.valueOf(result[2]);
				String videoThumbnail = String.valueOf(result[3]);
				String filename = String.valueOf(result[4]);
				String username = String.valueOf(result[5]);

				VideoDTO videoDTO = new VideoDTO(fileId, title, description, videoThumbnail, filename, username);
				videoDTOs.add(videoDTO);
			}

			return videoDTOs;

		} catch (Exception e) {
			logger.error("Unable to fetch the video details by filter");
			throw new CustomStreamException("Unable to fetch the video details by filter");
		}
	}

	public List<ScheduleVideoDTO> saveScheduleVideoDetails(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Received the request to check the request details is already existing or not before insert");
		try {
			List<Range> ranges = new ArrayList<>();
			List<ScheduleVideoDTO> scheduleVideoDTOs = null;
			logger.info("Formatted the details by schedule type to return the date and time");
			if (scheduleVideoRequestPojo.getScheduleType().equals("DayDateTime")) {
                logger.info("Get the formatted day date and time to add in range");
				ranges.add(getFormattedDateTimeRange(scheduleVideoRequestPojo.getStartDate(),
						scheduleVideoRequestPojo.getEndDate(), scheduleVideoRequestPojo.getZoneId(),
						scheduleVideoRequestPojo.getStartTime(), scheduleVideoRequestPojo.getEndTime()));

			} else {
				logger.info("Get the formatted day date and time with date range");
				ranges = generateDateRanges(scheduleVideoRequestPojo);
			}

			StoredProcedureQuery query = entityManager.createStoredProcedureQuery("ST_Schedule_Video_Records");

			query.registerStoredProcedureParameter("IN_zoneId", String.class, ParameterMode.IN);
			query.registerStoredProcedureParameter("IN_requestedDateTime", String.class, ParameterMode.IN);

			String datePojoJson = objectMapper.writeValueAsString(ranges);

			query.setParameter("IN_zoneId", scheduleVideoRequestPojo.getZoneId());
			query.setParameter("IN_requestedDateTime", datePojoJson);

			List<Object[]> resultList = query.getResultList();

			if (resultList.isEmpty()) {
				saveScheduleVideoDetailsByScheduleType(scheduleVideoRequestPojo);
				logger.info("Save the schedule video details in database based on schedule type");
				return scheduleVideoDTOs;
			} else {
				scheduleVideoDTOs = mapExistingResultsToDTOs(resultList, scheduleVideoRequestPojo);
				logger.info("Existing details to set as DTO to return as");
				return scheduleVideoDTOs;
			}
		} catch (Exception exception) {
			logger.error("Unable to save the schedule video details by schedule type");
			throw new CustomStreamException("Unable to save the schedule video details by schedule type");
		}
	}

	private Range getFormattedDateTimeRange(LocalDate startDate, LocalDate endDate, String zoneId, LocalTime startTime,
			LocalTime endTime) {
		logger.info("Convert the given date and time as given DateTimeFormatter pattern");
		try {
			logger.info("Convert the DateTimeFormatter pattern");
			LocalDateTime[] utcDateTimes = convertZoneDateTimeToUTCFormat(startDate, endDate, zoneId, startTime,
					endTime);
			String formattedStartDateTime = utcDateTimes[0].format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
			String formattedEndDateTime = utcDateTimes[1].format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
			logger.info("Given date and time is converted as DateTimeFormatter pattern");
			return new Range(formattedStartDateTime, formattedEndDateTime);
		} catch (DateTimeException e) {
			logger.error("Unable to convert the date and time as given pattern");
			throw new CustomStreamException("Unable to convert the date and time as given pattern");
		}
	}
	
	public LocalDateTime[] convertZoneDateTimeToUTCFormat(LocalDate startDate, LocalDate endDate, String zoneId,
			LocalTime startTime, LocalTime endTime) {
		logger.info("Received the request to convert the requested date and time as UTC dateTime format");
		try {
			logger.info("Received the details for UTC convert process");
			ZoneId requestZoneId = ZoneId.of(zoneId);
			LocalDateTime startDateTime = LocalDateTime.of(startDate, startTime);
			ZonedDateTime startZonedDateTime = ZonedDateTime.of(startDateTime, requestZoneId);
			LocalDateTime endDateTime = LocalDateTime.of(endDate, endTime);
			ZonedDateTime endZonedDateTime = ZonedDateTime.of(endDateTime, requestZoneId);

			LocalDateTime adjustedStartTime = startZonedDateTime.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();
			LocalDateTime adjustedEndTime = endZonedDateTime.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();

			logger.info("Given date and time is converted as UTC time");
			return new LocalDateTime[] { adjustedStartTime, adjustedEndTime };
		} catch (ZoneRulesException e) {
			logger.error("Unable to covert the date and time as UTC");
			throw new CustomStreamException("Unable to covert the date and time as UTC");
		}
	}
	
	private List<Range> generateDateRanges(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Received the request to formatted the date and time by schedule type");
		try {
			List<Range> ranges = new ArrayList<>();
			LocalDate currentDate = scheduleVideoRequestPojo.getStartDate();
			logger.info("Check the skipped date is available or not in requested date range");
			if (!scheduleVideoRequestPojo.getSkippedDates().isEmpty()) {
				logger.info("Skipped dates is available in given date range");
				while (!currentDate.isAfter(scheduleVideoRequestPojo.getEndDate())) {
					logger.info("Check current date is not after end date");
					if (!scheduleVideoRequestPojo.getSkippedDates().contains(currentDate)) {
						ranges.add(getFormattedDateTimeRange(currentDate, currentDate,
								scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
								scheduleVideoRequestPojo.getEndTime()));
					}
					currentDate = currentDate.plusDays(1);
				}
			} else {
			    logger.info("Skipped dates is not available for date range");
				while (!currentDate.isAfter(scheduleVideoRequestPojo.getEndDate())) {
					logger.info("Check current date is not after end date");
					ranges.add(getFormattedDateTimeRange(currentDate, currentDate, scheduleVideoRequestPojo.getZoneId(),
							scheduleVideoRequestPojo.getStartTime(), scheduleVideoRequestPojo.getEndTime()));
					currentDate = currentDate.plusDays(1);
				}

			}
			logger.info("Send the formatted date and time in given date range without skipped date's");
			return ranges;
		} catch (DateTimeException dateTimeException) {
			logger.error("Unable to get the date from given date range");
			throw new CustomStreamException("Unable to get the date from given date range");
		}
	}
	
	public boolean saveScheduleVideoDetailsByScheduleType(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Call the schedule video saving method by schedule type");
		try {
			logger.info("Check the schedule type is DayDateTime or other");
			boolean isScheduleType;
			if (scheduleVideoRequestPojo.getScheduleType().equals("DayDateTime")) {
				logger.info("Schedule type is DayDateTime");
				isScheduleType = saveDayDateAndTimeScheduleVideoDetails(scheduleVideoRequestPojo);
			} else {
				logger.info("Schedule type is DateRange or other");
				if (scheduleVideoRequestPojo.getSkippedDates().isEmpty()) {
					logger.info("Call the date range method");
					isScheduleType = saveDateRangeScheduleVideoDetails(scheduleVideoRequestPojo);
				} else {
					logger.info("Call the skipped date range method");
					isScheduleType = saveSkippedDateRangeScheduleVideoDetails(scheduleVideoRequestPojo);
				}
			}
			logger.info("Identified the saving method schedule type");
			return isScheduleType;
		} catch (Exception e) {
			logger.error("Unable to identify the saving method schedule type");
			throw new CustomStreamException("Unable to identify the saving method schedule type");
		}

	}
	
	public boolean saveDayDateAndTimeScheduleVideoDetails(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Received the request to save the day date time schedule video details");
		try {
			logger.info("Zone based day date time video saving process started...");
			User user = userRepository.findByUsername(scheduleVideoRequestPojo.getUsername());

			LocalDateTime[] utcDateTimes = convertZoneDateTimeToUTCFormat(scheduleVideoRequestPojo.getStartDate(),
					scheduleVideoRequestPojo.getEndDate(), scheduleVideoRequestPojo.getZoneId(),
					scheduleVideoRequestPojo.getStartTime(), scheduleVideoRequestPojo.getEndTime());

			ScheduleVideo scheduleVideo = setScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
					scheduleVideoRequestPojo.getFilename(), utcDateTimes[0], utcDateTimes[1], user.getName());

			UserScheduleVideo userScheduleVideo = setUserScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
					scheduleVideoRequestPojo.getFilename(), utcDateTimes[0], utcDateTimes[1], user.getName());

			userScheduleVideo.setScheduleVideo(scheduleVideo);

			scheduleVideoRepository.save(scheduleVideo);
			userScheduleVideoRepository.save(userScheduleVideo);
          
			logger.info("Schedule video details are saved in database");
			return true;
		} catch (Exception exception) {
			logger.error("Unable to save schedule video details in database");
			return false;
		}

	}
	
	public boolean saveDateRangeScheduleVideoDetails(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Received the request to save the date range in requested dates and time");
		try {
			LocalDate currentDate = scheduleVideoRequestPojo.getStartDate();
			
			logger.info("Get the  video details and date range from requested dates and time ");
			List<UserScheduleVideo> userScheduleVideos = new ArrayList<>();

			LocalDateTime[] utcDateTimes = convertZoneDateTimeToUTCFormat(scheduleVideoRequestPojo.getStartDate(),
					scheduleVideoRequestPojo.getEndDate(), scheduleVideoRequestPojo.getZoneId(),
					scheduleVideoRequestPojo.getStartTime(), scheduleVideoRequestPojo.getEndTime());

			User user = userRepository.findByUsername(scheduleVideoRequestPojo.getUsername());

			ScheduleVideo scheduleVideo = setScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
					scheduleVideoRequestPojo.getFilename(), utcDateTimes[0], utcDateTimes[1], user.getName());

			while (!currentDate.isAfter(scheduleVideoRequestPojo.getEndDate())) {
				logger.info("Check the current date is not after the end date");
				LocalDateTime[] utcRangeDateTimes = convertZoneDateTimeToUTCFormat(currentDate, currentDate,
						scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
						scheduleVideoRequestPojo.getEndTime());

				UserScheduleVideo userScheduleVideo = setUserScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
						scheduleVideoRequestPojo.getFilename(), utcRangeDateTimes[0], utcRangeDateTimes[1],
						user.getName());

				userScheduleVideo.setScheduleVideo(scheduleVideo);

				userScheduleVideos.add(userScheduleVideo);

				currentDate = currentDate.plusDays(1);
				logger.info("Set the each individual video details and date in user schedule video");
			}
			
			scheduleVideoRepository.save(scheduleVideo);
			userScheduleVideoRepository.saveAll(userScheduleVideos);
			
			logger.info("Save the schedule video details with individual dates and date range in database ");
			return true;
		} catch (Exception e) {
			logger.error("Unable to save the schedule video details with individual dates and date range in database");
			return false;
		}

	}

	public boolean saveSkippedDateRangeScheduleVideoDetails(ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
	    logger.info("Received the requested to save the date range without skipped date's in database");
		try {
			logger.info("Video details saving process started in date range without skipped date's ");
	        List<ScheduleVideo> scheduleVideos = new ArrayList<>();
	        List<UserScheduleVideo> userScheduleVideos = new ArrayList<>();
	        
	        LocalDate startDate = scheduleVideoRequestPojo.getStartDate();
	        LocalDate endDate = scheduleVideoRequestPojo.getEndDate();

	        User user = userRepository.findByUsername(scheduleVideoRequestPojo.getUsername());
	        
	        LocalDate currentStartDate = startDate;
	        
	        for (LocalDate skippedDate : scheduleVideoRequestPojo.getSkippedDates()) {
	            if (!currentStartDate.isEqual(skippedDate)) {
	                logger.info("Check the currnet start date is not equal to the skipped date in list");
	            	LocalDateTime[] utcRangeDateTimes = convertZoneDateTimeToUTCFormat(currentStartDate, skippedDate.minusDays(1),
	                        scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
	                        scheduleVideoRequestPojo.getEndTime());
	                
	                ScheduleVideo scheduleVideo = setScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
	    					scheduleVideoRequestPojo.getFilename(), utcRangeDateTimes[0], utcRangeDateTimes[1],
	    					user.getName());

	                scheduleVideos.add(scheduleVideo);
	                logger.info("Set the schedule video details with date range");
	                while (!currentStartDate.isAfter(skippedDate.minusDays(1))) {
	                	logger.info("Check the current start date is not after the previous date of skipped date");
	                	LocalDateTime[] utcRangeDateTime = convertZoneDateTimeToUTCFormat(currentStartDate, currentStartDate,
		                            scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
		                            scheduleVideoRequestPojo.getEndTime());
		                
		                UserScheduleVideo userScheduleVideo = setUserScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
	    						scheduleVideoRequestPojo.getFilename(), utcRangeDateTime[0], utcRangeDateTime[1],
	    						user.getName());
		                
		                userScheduleVideo.setScheduleVideo(scheduleVideo);
		                userScheduleVideos.add(userScheduleVideo);
		                
		                currentStartDate = currentStartDate.plusDays(1);
		            }  
	               
	            }
	            currentStartDate = skippedDate.plusDays(1);
	        }

	        if (!currentStartDate.isAfter(endDate)) {
	        	logger.info("Check the current start date is not after the end date");
	        	LocalDateTime[] utcRangeDateTimes = convertZoneDateTimeToUTCFormat(currentStartDate, endDate,
	                    scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
	                    scheduleVideoRequestPojo.getEndTime());
	            
	            ScheduleVideo scheduleVideo = setScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
    					scheduleVideoRequestPojo.getFilename(), utcRangeDateTimes[0], utcRangeDateTimes[1],
    					user.getName());
	            
	            scheduleVideos.add(scheduleVideo);
	            
	            logger.info("Set the schedule video details with after skipped date and end date range");
	            while (!currentStartDate.isAfter(endDate)) {
	            	logger.info("Check the current start date is not after the end date");
	                LocalDateTime[] utcRangeDateTime = convertZoneDateTimeToUTCFormat(currentStartDate, currentStartDate,
	                        scheduleVideoRequestPojo.getZoneId(), scheduleVideoRequestPojo.getStartTime(),
	                        scheduleVideoRequestPojo.getEndTime());
	                
	                UserScheduleVideo userScheduleVideo = setUserScheduleVideoDetails(scheduleVideoRequestPojo.getZoneId(),
    						scheduleVideoRequestPojo.getFilename(), utcRangeDateTime[0], utcRangeDateTime[1],
    						user.getName());
	           
	                userScheduleVideo.setScheduleVideo(scheduleVideo);
	                userScheduleVideos.add(userScheduleVideo);
	                
	                currentStartDate = currentStartDate.plusDays(1);
	            }
	        }

	        scheduleVideoRepository.saveAll(scheduleVideos);
	        userScheduleVideoRepository.saveAll(userScheduleVideos);
	        
	        logger.info("Save the schedule video details with skipped dates in date range in database");
	        return true;
	    } catch (Exception e) {
	        logger.error("Unable to save the schedule video details  with skipped dates in date range");
	        return false;
	    }
	}

	public ScheduleVideo setScheduleVideoDetails(String zoneId, String filename, LocalDateTime startDateTime,
			LocalDateTime endDateTime, String name) {
		logger.info("Gathering the details from request to set as corresponding fields");
		try {
			logger.info("Get the details from request to set schedule video fields");
			ScheduleVideo scheduleVideo = new ScheduleVideo();

			scheduleVideo.setZoneId(zoneId);
			scheduleVideo.setFilename(filename);
			scheduleVideo.setStartDateTime(Timestamp.valueOf(startDateTime));
			scheduleVideo.setEndDateTime(Timestamp.valueOf(endDateTime));
			scheduleVideo.setCreatedBy(name);
			scheduleVideo.setUpdatedBy(name);
			
			logger.info("Return the schedule video details form schedule video entity");
			return scheduleVideo;
		} catch (Exception e) {
			logger.error("Unable to set the requested details in schedule video");
			throw new CustomStreamException("Unable to set the requested details in schedule video");
		}
	}

	public UserScheduleVideo setUserScheduleVideoDetails(String zoneId, String filename, LocalDateTime startDateTime,
			LocalDateTime endDateTime, String name) {
		logger.info("Gathering the details from request to set as user schedule video fields");
		try {
			logger.info("Set the details from request to user schedule video fields");
			UserScheduleVideo userScheduleVideo = new UserScheduleVideo();

			userScheduleVideo.setZoneId(zoneId);
			userScheduleVideo.setFilename(filename);
			userScheduleVideo.setStartDateTime(Timestamp.valueOf(startDateTime));
			userScheduleVideo.setEndDateTime(Timestamp.valueOf(endDateTime));
			userScheduleVideo.setCreatedBy(name);
			userScheduleVideo.setUpdatedBy(name);
			
			logger.info("Return the schedule video details from user schedule video entity");
			return userScheduleVideo;
		} catch (Exception e) {
			logger.error("Unable to set the requested details in user schedule video");
			throw new CustomStreamException("Unable to set the requested details in user schedule video");
		}
	}
	
	private List<ScheduleVideoDTO> mapExistingResultsToDTOs(List<Object[]> resultList,
			ScheduleVideoRequestPojo scheduleVideoRequestPojo) {
		logger.info("Get the details from result to set the DTO fields");
		try {
			logger.info("Set the details from stored procedure result");
			List<ScheduleVideoDTO> scheduleVideoDTOs = new ArrayList<>();

			for (Object[] result : resultList) {
				int scheduleId = (int) result[0];
				String zoneId = String.valueOf(result[4]);
				String filename = String.valueOf(result[1]);

				String dateTimePattern = "yyyy-MM-dd HH:mm:ss.S";
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateTimePattern);
				LocalDateTime startTime = LocalDateTime.parse(String.valueOf(result[2]), formatter);
				LocalDateTime endTime = LocalDateTime.parse(String.valueOf(result[3]), formatter);

				ZoneId requestZoneId = ZoneId.of(scheduleVideoRequestPojo.getZoneId());
				ZonedDateTime zonedStartTime = startTime.atZone(ZoneOffset.UTC).withZoneSameInstant(requestZoneId);
				ZonedDateTime zonedEndTime = endTime.atZone(ZoneOffset.UTC).withZoneSameInstant(requestZoneId);

				ScheduleVideoDTO scheduleVideoDTO = new ScheduleVideoDTO(scheduleId, zoneId, filename,
						zonedStartTime.toLocalDateTime(), zonedEndTime.toLocalDateTime());
				scheduleVideoDTOs.add(scheduleVideoDTO);
			}
			logger.info("Return the DTO details...");
			return scheduleVideoDTOs;
		} catch (Exception e) {
			logger.error("Unable to set the result in DTO fields");
			throw new CustomStreamException("Unable to set the result in DTO fields");
		}
		
	}

	public ScheduleVideoDTO fetchZonedLocalTimeScheduleVideoDetails(ZoneDateTimeRequest zoneDateTimeRequest) {
        logger.info("Received the request to fetch the schedule video details by zoned local time");
        ScheduleVideoDTO scheduleVideoDTO=null;
        try {
        	logger.info("Get the schedule video details by zoned local time");
            ZoneId localZoneId = ZoneId.of(zoneDateTimeRequest.getZoneId());
 
        	ZonedDateTime zonedDateTime = ZonedDateTime.of(zoneDateTimeRequest.getLocalDateTime(), localZoneId);
        	
        	LocalDateTime adjustedDateTime = zonedDateTime.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();
        	
            String formattedDateTime = adjustedDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

            String jpql = "SELECT * FROM user_schedule_video " +
                    "WHERE zone_id = ? " +
                    "AND DATE_FORMAT(start_date_time,'%Y-%m-%d %H:%i') <= ? " +
                    "AND DATE_FORMAT(end_date_time,'%Y-%m-%d %H:%i') >= ?";

            Query query = entityManager.createNativeQuery(jpql);
            query.setParameter(1, zoneDateTimeRequest.getZoneId());
            query.setParameter(2, formattedDateTime);
            query.setParameter(3, formattedDateTime);

            Object resultList=query.getSingleResult();
            
            if (resultList != null) {
            	logger.info("Details are available in requested zoned date time");
                Object[] row = (Object[]) resultList;
                
                LocalDateTime localDateTime=((Timestamp) row[3]).toLocalDateTime();
                
                ZonedDateTime zonedStartTime = localDateTime.atZone(ZoneOffset.UTC).withZoneSameInstant(localZoneId);
            	
                scheduleVideoDTO = new ScheduleVideoDTO(
                        (int) row[0],              
                        (String) row[8],            
                        (String) row[4],            
                        zoneDateTimeRequest.getLocalDateTime(),
                        zonedStartTime.toLocalDateTime()  
                );
            }
            logger.info("Schedule video details are set in DTO to return");
            return scheduleVideoDTO;
        } catch (NoResultException exception) {
            logger.warn("No video found for requested zone id");
            return scheduleVideoDTO; 
        } catch (Exception e) {
            logger.error("Unable to fetch the video details by zoned date time");
            throw new CustomStreamException("Unable to fetch the video details by zoned date time");
        }
    }
	
}

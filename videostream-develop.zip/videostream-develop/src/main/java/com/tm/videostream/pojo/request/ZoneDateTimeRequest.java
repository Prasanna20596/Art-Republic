package com.tm.videostream.pojo.request;

import java.time.LocalDateTime;

public class ZoneDateTimeRequest {

	private String zoneId;
	private LocalDateTime localDateTime;

	public String getZoneId() {
		return zoneId;
	}

	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

}

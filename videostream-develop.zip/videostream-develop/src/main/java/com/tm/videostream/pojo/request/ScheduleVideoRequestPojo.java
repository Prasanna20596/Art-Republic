package com.tm.videostream.pojo.request;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ScheduleVideoRequestPojo {

	@NotBlank(message = "Username cannot be blank or null")
	private String username;
	@NotBlank(message = "Zone id cannot be blank or null")
	private String zoneId;
	@NotBlank(message = "Filename cannot be blank or null")
	private String filename;
	@NotNull(message = "Start time cannot be null")
	private LocalTime startTime;
	@NotNull(message = "End time cannot be null")
	private LocalTime endTime;
	@NotNull(message = "Start date cannot be null")
	private LocalDate startDate;
	@NotNull(message = "End date cannot be null")
	private LocalDate endDate;
	@NotBlank(message = "Schedule type cannot be blank or null")
	private String scheduleType;
	private List<LocalDate> skippedDates;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getZoneId() {
		return zoneId;
	}

	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getScheduleType() {
		return scheduleType;
	}

	public void setScheduleType(String scheduleType) {
		this.scheduleType = scheduleType;
	}

	public List<LocalDate> getSkippedDates() {
		return skippedDates;
	}

	public void setSkippedDates(List<LocalDate> skippedDates) {
		this.skippedDates = skippedDates;
	}

}

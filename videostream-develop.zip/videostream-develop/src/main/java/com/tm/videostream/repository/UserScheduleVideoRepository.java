package com.tm.videostream.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tm.videostream.entity.UserScheduleVideo;

public interface UserScheduleVideoRepository extends JpaRepository<UserScheduleVideo, Integer> {

	
}
